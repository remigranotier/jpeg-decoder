#ifndef __ZIG_ZAG_H__
#define __ZIG_ZAG_H__
#include <stdint.h>



extern int16_t **zig_zag_inverse(int16_t *vecteur_freq);
// Copie  le vecteur dans un tableau selon les zig-zag de l'énoncé 2.3.2


#endif
